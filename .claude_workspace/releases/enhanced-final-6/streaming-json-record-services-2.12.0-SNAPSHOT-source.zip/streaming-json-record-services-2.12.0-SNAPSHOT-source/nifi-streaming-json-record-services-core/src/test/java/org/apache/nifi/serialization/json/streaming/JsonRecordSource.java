/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.nifi.serialization.json.streaming;

import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.databind.JsonNode;
import org.apache.nifi.schema.inference.RecordSource;

import java.io.IOException;
import java.io.InputStream;

final class JsonRecordSource implements RecordSource<JsonNode> {
    private final JsonParserRecordSource parserRecordSource;

    public JsonRecordSource(final InputStream in) throws IOException {
        parserRecordSource = new JsonParserRecordSource(in);
    }

    public JsonRecordSource(final InputStream in, final StartingFieldStrategy strategy, final String startingFieldName, final TokenParserFactory tokenParserFactory) throws IOException {
        parserRecordSource = new JsonParserRecordSource(in, strategy, startingFieldName, tokenParserFactory);
    }

    @Override
    public JsonNode next() throws IOException {
        final JsonParser jsonParser = parserRecordSource.next();
        return jsonParser == null ? null : jsonParser.readValueAsTree();
    }
}
