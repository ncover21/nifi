/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.apache.nifi.serialization.json.streaming;

import org.apache.nifi.components.DescribedValue;

enum TimestampRepresentation implements DescribedValue {
    AUTO("Automatic", "Uses the configured Timestamp Format when present, otherwise writes epoch milliseconds"),
    FORMATTED_STRING("Formatted String", "Writes timestamps as strings using the configured Timestamp Format"),
    EPOCH_MILLISECONDS("Epoch Milliseconds", "Writes timestamps as integer JSON numbers containing milliseconds since the Unix epoch"),
    EPOCH_SECONDS("Epoch Seconds", "Writes timestamps as decimal JSON numbers containing seconds since the Unix epoch with millisecond precision");

    private final String displayName;
    private final String description;

    TimestampRepresentation(final String displayName, final String description) {
        this.displayName = displayName;
        this.description = description;
    }

    @Override
    public String getDisplayName() {
        return displayName;
    }

    @Override
    public String getDescription() {
        return description;
    }

    @Override
    public String getValue() {
        return name();
    }
}
